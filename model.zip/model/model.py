import torch
import torch.nn as nn
import torch.nn.functional as F
import math


class TemporalEmbedding(nn.Module):
    def __init__(self, hidden_dim):
        super(TemporalEmbedding, self).__init__()
        self.hour_embed = nn.Embedding(24, hidden_dim)

    def forward(self, hour_idx):
        h_emb = self.hour_embed(hour_idx)
        return h_emb.unsqueeze(2)


class EnhancedLSTMCell(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super(EnhancedLSTMCell, self).__init__()
        self.hidden_dim = hidden_dim
        self.gate_linear = nn.Linear(input_dim + hidden_dim, 4 * hidden_dim)

    def forward(self, x_t, h_prev, c_prev, delta_t):
        return None


class ImprovedLSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim):
        super(ImprovedLSTM, self).__init__()
        self.hidden_dim = hidden_dim
        self.cell = EnhancedLSTMCell(input_dim, hidden_dim)

    def forward(self, x, delta):
        batch_size, seq_len, _ = x.shape
        h = torch.zeros(batch_size, self.hidden_dim, device=x.device)
        c = torch.zeros(batch_size, self.hidden_dim, device=x.device)

        for t in range(seq_len):
            h, c = self.cell(x[:, t, :], h, c, delta[:, t, :])

        return h


class GCNLayer(nn.Module):
    def __init__(self, in_features, out_features):
        super(GCNLayer, self).__init__()
        self.linear = nn.Linear(in_features, out_features)
        self.shortcut = (nn.Linear(in_features, out_features)
                         if in_features != out_features else nn.Identity())

    def forward(self, x, adj):
        residual = self.shortcut(x)
        out = self.linear(x)
        out = torch.matmul(adj, out)
        return F.relu(out + residual)


class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=5000):
        super(PositionalEncoding, self).__init__()
        with torch.no_grad():
            pe = torch.zeros(max_len, d_model)
            position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
            div_term = torch.exp(torch.arange(0, d_model, 2).float()
                                 * (-math.log(10000.0) / d_model))
            pe[:, 0::2] = torch.sin(position * div_term)
            pe[:, 1::2] = torch.cos(position * div_term)
            pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        return x + self.pe[:, :x.size(1), :]


class GateFusion(nn.Module):
    def __init__(self, hidden_dim):
        super(GateFusion, self).__init__()
        self.gate_linear = nn.Linear(hidden_dim * 2, hidden_dim)

    def forward(self, h_a, h_b):
        concat = torch.cat([h_a, h_b], dim=-1)
        z = torch.sigmoid(self.gate_linear(concat))
        return z * h_a + (1.0 - z) * h_b


class MVP_STG(nn.Module):
    def __init__(self, num_nodes, input_dim, output_len,
                 hidden_dim=128, input_len=12):
        super(MVP_STG, self).__init__()
        self.num_nodes = num_nodes
        self.input_len = input_len
        self.hidden_dim = hidden_dim

        self.input_embedding = nn.Linear(input_dim, hidden_dim)
        self.temporal_embed = TemporalEmbedding(hidden_dim)

        self.gcn1 = GCNLayer(hidden_dim, hidden_dim)
        self.gcn2 = GCNLayer(hidden_dim, hidden_dim)

        self.lstm = ImprovedLSTM(hidden_dim, hidden_dim)

        self.pos_encoder = PositionalEncoding(hidden_dim)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_dim, nhead=4, batch_first=True,
            dropout=0.1, activation='gelu'
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=1)

        self.short_fusion = GateFusion(hidden_dim)
        self.global_fusion = GateFusion(hidden_dim)

        self.output_head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, output_len)
        )

    def forward(self, x, adj, hour_idx, delta):
        B, T, N = x.shape

        x_in = x.unsqueeze(-1)
        emb = self.input_embedding(x_in)
        t_emb = self.temporal_embed(hour_idx)
        emb = emb + t_emb

        gcn_pool = emb.mean(dim=1)
        gcn_out = self.gcn2(self.gcn1(gcn_pool, adj), adj)
        H_GCN = gcn_out

        lstm_in = emb.permute(0, 2, 1, 3).reshape(B * N, T, -1)
        delta_lstm = delta.permute(0, 2, 1).reshape(B * N, T, 1)
        H_LSTM = self.lstm(lstm_in, delta_lstm)
        H_LSTM = H_LSTM.reshape(B, N, -1)

        trans_in = emb.permute(0, 2, 1, 3).reshape(B * N, T, -1)
        trans_out = self.pos_encoder(trans_in)
        trans_out = self.transformer(trans_out)
        trans_out = trans_out + trans_in
        trans_pool = trans_out.mean(dim=1)
        H_Trans = trans_pool.reshape(B, N, -1)

        H_short = self.short_fusion(H_LSTM, H_GCN)
        H_fused = self.global_fusion(H_short, H_Trans)

        Y_D = self.output_head(H_fused)
        Y = Y_D

        return Y.permute(0, 2, 1)
