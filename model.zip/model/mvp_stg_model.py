import math
from typing import Any, Dict, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 5000, dropout: float = 0.1):
        super().__init__()
        self.dropout = nn.Dropout(dropout)

        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(
            torch.arange(0, d_model, 2, dtype=torch.float32) * (-math.log(10000.0) / d_model)
        )
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe.unsqueeze(1), persistent=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x + self.pe[: x.size(0)]
        return self.dropout(x)


class MultiHeadAttention(nn.Module):
    def __init__(self, d_model: int, num_heads: int, dropout: float = 0.1):
        super().__init__()
        if d_model % num_heads != 0:
            raise ValueError("d_model must be divisible by num_heads")

        self.d_model = d_model
        self.num_heads = num_heads
        self.d_k = d_model // num_heads
        self.scale = math.sqrt(self.d_k)

        self.w_q = nn.Linear(d_model, d_model)
        self.w_k = nn.Linear(d_model, d_model)
        self.w_v = nn.Linear(d_model, d_model)
        self.w_o = nn.Linear(d_model, d_model)
        self.dropout = nn.Dropout(dropout)

    def scaled_dot_product_attention(
        self,
        q: torch.Tensor,
        k: torch.Tensor,
        v: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        scores = torch.matmul(q, k.transpose(-2, -1)) / self.scale
        if mask is not None:
            mask = mask.unsqueeze(0).unsqueeze(0)
            scores = scores.masked_fill(mask == 0, torch.finfo(scores.dtype).min)
        attention = F.softmax(scores, dim=-1)
        attention = self.dropout(attention)
        output = torch.matmul(attention, v)
        return output, attention

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        seq_len, batch_size, _ = query.shape
        q = self.w_q(query).view(seq_len, batch_size, self.num_heads, self.d_k).permute(1, 2, 0, 3)
        k = self.w_k(key).view(seq_len, batch_size, self.num_heads, self.d_k).permute(1, 2, 0, 3)
        v = self.w_v(value).view(seq_len, batch_size, self.num_heads, self.d_k).permute(1, 2, 0, 3)

        output, attention = self.scaled_dot_product_attention(q, k, v, mask)
        output = output.permute(2, 0, 1, 3).contiguous().view(seq_len, batch_size, self.d_model)
        return self.w_o(output), attention


class PositionwiseFeedForward(nn.Module):
    def __init__(self, d_model: int, d_ff: int, dropout: float = 0.1):
        super().__init__()
        self.linear1 = nn.Linear(d_model, d_ff)
        self.linear2 = nn.Linear(d_ff, d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.linear2(self.dropout(F.relu(self.linear1(x))))


class TransformerEncoderLayer(nn.Module):
    def __init__(self, d_model: int, num_heads: int, d_ff: int, dropout: float = 0.1):
        super().__init__()
        self.self_attention = MultiHeadAttention(d_model, num_heads, dropout)
        self.feed_forward = PositionwiseFeedForward(d_model, d_ff, dropout)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(
        self,
        x: torch.Tensor,
        mask: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        attn_output, attn_weights = self.self_attention(x, x, x, mask)
        x = self.norm1(x + self.dropout(attn_output))
        ff_output = self.feed_forward(x)
        x = self.norm2(x + self.dropout(ff_output))
        return x, attn_weights


class TransformerEncoder(nn.Module):
    def __init__(
        self,
        d_model: int,
        num_heads: int,
        num_layers: int,
        d_ff: int,
        max_len: int = 5000,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.pos_encoding = PositionalEncoding(d_model, max_len, dropout)
        self.layers = nn.ModuleList(
            [TransformerEncoderLayer(d_model, num_heads, d_ff, dropout) for _ in range(num_layers)]
        )
        self.norm = nn.LayerNorm(d_model)

    def create_causal_mask(self, seq_len: int, device: torch.device) -> torch.Tensor:
        return torch.tril(torch.ones(seq_len, seq_len, device=device))

    def forward(self, x: torch.Tensor, causal_mask: bool = False) -> Tuple[torch.Tensor, list]:
        if x.dim() != 3:
            raise ValueError("TransformerEncoder expects a 3D tensor")

        x = x.transpose(0, 1)
        mask = self.create_causal_mask(x.size(0), x.device) if causal_mask else None
        x = self.pos_encoding(x)

        attention_weights = []
        for layer in self.layers:
            x, attn = layer(x, mask)
            attention_weights.append(attn)

        x = self.norm(x)
        return x.transpose(0, 1), attention_weights


class TransformerModule(nn.Module):
    def __init__(
        self,
        d_model: int = 128,
        num_heads: int = 4,
        num_layers: int = 1,
        d_ff: int = 256,
        dropout: float = 0.1,
        causal_mask: bool = False,
        max_seq_len: int = 5000,
    ):
        super().__init__()
        self.causal_mask = causal_mask
        self.transformer = TransformerEncoder(
            d_model=d_model,
            num_heads=num_heads,
            num_layers=num_layers,
            d_ff=d_ff,
            max_len=max_seq_len,
            dropout=dropout,
        )

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, list]:
        return self.transformer(x, causal_mask=self.causal_mask)


class TemporalEmbedding(nn.Module):
    def __init__(self, d_model: int):
        super().__init__()
        self.hour_embedding = nn.Embedding(24, d_model)
        self.day_embedding = nn.Embedding(7, d_model)

    @staticmethod
    def _to_index(values: torch.Tensor, upper: int) -> torch.Tensor:
        if torch.is_floating_point(values):
            values = values.clone()
            if torch.all((values >= 0) & (values <= 1)):
                values = torch.round(values * float(upper - 1))
            else:
                values = torch.round(values)
        return values.long().clamp(0, upper - 1)

    def forward(self, time_features: torch.Tensor) -> torch.Tensor:
        if time_features.size(-1) < 2:
            raise ValueError("time_features must contain at least hour-of-day and day-of-week")
        hour_idx = self._to_index(time_features[..., 0], 24)
        day_idx = self._to_index(time_features[..., 1], 7)
        return self.hour_embedding(hour_idx) + self.day_embedding(day_idx)


class FluctuationAwareGate(nn.Module):
    def __init__(self, input_size: int, hidden_size: int, window_size: int = 3):
        super().__init__()
        if window_size < 1:
            raise ValueError("window_size must be >= 1")
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.window_size = window_size
        self.gate_projection = nn.Linear(1, hidden_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, seq_len, _ = x.shape
        delta = torch.zeros(batch_size, seq_len, 1, device=x.device, dtype=x.dtype)

        for t in range(self.window_size - 1, seq_len):
            window = x[:, t - self.window_size + 1 : t + 1, :]
            mean = window.mean(dim=1, keepdim=True)
            squared_l2 = ((window - mean) ** 2).sum(dim=-1)
            rms_deviation = torch.sqrt(squared_l2.mean(dim=1, keepdim=True) + 1e-8)
            delta[:, t, :] = rms_deviation

        return torch.sigmoid(self.gate_projection(delta))


class ImprovedLSTMCell(nn.Module):
    def __init__(self, input_size: int, hidden_size: int):
        super().__init__()
        self.hidden_size = hidden_size

        self.input_gate = nn.Linear(input_size + hidden_size, hidden_size)
        self.forget_gate = nn.Linear(input_size + hidden_size, hidden_size)
        self.output_gate = nn.Linear(input_size + hidden_size, hidden_size)
        self.candidate_gate = nn.Linear(input_size + hidden_size, hidden_size)

        self.residual_x = nn.Linear(input_size, hidden_size)
        self.residual_h = nn.Linear(hidden_size, hidden_size, bias=False)
        self.input_projection = nn.Linear(input_size, hidden_size) if input_size != hidden_size else nn.Identity()

    def forward(
        self,
        x_t: torch.Tensor,
        hidden_state: Tuple[torch.Tensor, torch.Tensor],
        fluctuation_gate: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        h_prev, c_prev = hidden_state
        combined = torch.cat([h_prev, x_t], dim=-1)

        f_t = torch.sigmoid(self.forget_gate(combined))
        i_t = torch.sigmoid(self.input_gate(combined))
        o_t = torch.sigmoid(self.output_gate(combined))
        c_tilde = torch.tanh(self.candidate_gate(combined))

        c_t = f_t * c_prev + (fluctuation_gate * i_t) * c_tilde

        residual_gate = torch.sigmoid(self.residual_x(x_t) + self.residual_h(h_prev))
        residual_input = self.input_projection(x_t)
        h_out = o_t * torch.tanh(c_t) + residual_gate * residual_input
        return h_out, c_t


class VolatilityAwareLSTM(nn.Module):
    def __init__(
        self,
        input_size: int,
        hidden_size: int,
        num_layers: int = 1,
        dropout: float = 0.0,
        fluctuation_window: int = 3,
    ):
        super().__init__()
        if num_layers < 1:
            raise ValueError("num_layers must be >= 1")

        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.dropout = nn.Dropout(dropout) if dropout > 0 else None

        self.cells = nn.ModuleList()
        self.fluctuation_gates = nn.ModuleList()
        for layer_idx in range(num_layers):
            layer_input = input_size if layer_idx == 0 else hidden_size
            self.cells.append(ImprovedLSTMCell(layer_input, hidden_size))
            self.fluctuation_gates.append(
                FluctuationAwareGate(layer_input, hidden_size, window_size=fluctuation_window)
            )

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        current_sequence = x

        pass

        return none

class GraphConvolution(nn.Module):
    def __init__(self, in_features: int, out_features: int, activation: Optional[str] = "relu"):
        super().__init__()
        self.weight = nn.Parameter(torch.empty(in_features, out_features))
        self.bias = nn.Parameter(torch.empty(out_features))

        if activation == "relu":
            self.activation = F.relu
        elif activation == "tanh":
            self.activation = torch.tanh
        elif activation == "sigmoid":
            self.activation = torch.sigmoid
        elif activation in ("none", None):
            self.activation = lambda x: x
        else:
            raise ValueError(f"Unsupported activation: {activation}")

        self.reset_parameters()

    def reset_parameters(self) -> None:
        bound = 1.0 / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-bound, bound)
        self.bias.data.uniform_(-bound, bound)

    def forward(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        if x.dim() == 2:
            support = torch.matmul(x, self.weight)
            output = torch.matmul(adj, support)
        elif x.dim() == 3:
            support = torch.matmul(x, self.weight)
            if adj.dim() == 2:
                adj = adj.unsqueeze(0).expand(x.size(0), -1, -1)
            output = torch.bmm(adj, support)
        else:
            raise ValueError("GraphConvolution expects 2D or 3D inputs")

        return self.activation(output + self.bias)


class GCNModule(nn.Module):
    def __init__(
        self,
        d_model: int = 128,
        hidden_size: int = 128,
        num_layers: int = 2,
        activation: str = "relu",
        aggregation: str = "mean",
    ):
        super().__init__()
        if num_layers < 1:
            raise ValueError("num_layers must be >= 1")
        self.aggregation = aggregation

        layers = []
        for layer_idx in range(num_layers):
            in_features = d_model if layer_idx == 0 else hidden_size
            layers.append(GraphConvolution(in_features, hidden_size, activation=activation))
        self.layers = nn.ModuleList(layers)

    def aggregate_temporal_features(self, x: torch.Tensor) -> torch.Tensor:
        if self.aggregation == "mean":
            return x.mean(dim=1)
        if self.aggregation == "last":
            return x[:, -1, :, :]
        raise ValueError(f"Unsupported aggregation: {self.aggregation}")

    def forward(self, x: torch.Tensor, adj: torch.Tensor) -> torch.Tensor:
        if x.dim() == 4:
            x = self.aggregate_temporal_features(x)

        h = x
        for layer in self.layers:
            h = layer(h, adj)
        return h


class SpatialTemporalFusion(nn.Module):
    def __init__(self, lstm_dim: int, gcn_dim: int, output_dim: int):
        super().__init__()
        pass

    def forward(self, lstm_output: torch.Tensor, gcn_output: torch.Tensor) -> torch.Tensor:
        return None


class ShortLongFusion(nn.Module):
    def __init__(self, d_model: int):
        super().__init__()
        pass

    def forward(self, short_features: torch.Tensor, long_features: torch.Tensor) -> torch.Tensor:
        return None


class FusionModule(nn.Module):
    def __init__(self, d_model: int = 128, lstm_hidden: int = 128, gcn_hidden: int = 128):
        super().__init__()
        self.spatial_temporal_fusion = SpatialTemporalFusion(lstm_hidden, gcn_hidden, d_model)
        self.short_long_fusion = ShortLongFusion(d_model)

    def forward(
        self,
        lstm_output: torch.Tensor,
        gcn_output: torch.Tensor,
        transformer_output: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        short_features = self.spatial_temporal_fusion(lstm_output, gcn_output)
        fused_features = self.short_long_fusion(short_features, transformer_output)
        return short_features, fused_features


class PredictionHead(nn.Module):
    def __init__(self, input_dim: int, forecast_steps: int, hidden_dim: Optional[int] = None):
        super().__init__()
        if hidden_dim is None:
            hidden_dim = input_dim
        self.forecast_steps = forecast_steps
        self.mlp = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, forecast_steps),
        )

    def forward(self, features: torch.Tensor) -> torch.Tensor:
        dynamic_prediction = self.mlp(features)
        return dynamic_prediction.transpose(1, 2)


class TrendPreservingResidualOutput(nn.Module):
    def __init__(self, input_dim: int, forecast_steps: int, beta_init: float = 0.1):
        super().__init__()
        self.forecast_steps = forecast_steps
        self.prediction_head = PredictionHead(input_dim, forecast_steps)
        self.beta = nn.Parameter(torch.tensor(beta_init, dtype=torch.float32))

    def build_reference(self, input_sequence: torch.Tensor) -> torch.Tensor:
        last_observation = input_sequence[:, -1, :]
        return last_observation.unsqueeze(1).expand(-1, self.forecast_steps, -1)

    def forward(
        self,
        features: torch.Tensor,
        input_sequence: torch.Tensor,
        low_freq: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        dynamic_prediction = self.prediction_head(features)
        reference = self.build_reference(input_sequence)
        final_prediction = dynamic_prediction + self.beta * reference
        return final_prediction, reference, dynamic_prediction


class MVPSTGPlusPlus(nn.Module):
    def __init__(
        self,
        input_len: int = 12,
        horizon: int = 12,
        d_model: int = 128,
        lstm_hidden: int = 128,
        lstm_layers: int = 1,
        lstm_dropout: float = 0.0,
        fluctuation_window: int = 3,
        gcn_hidden: int = 128,
        gcn_layers: int = 2,
        gcn_activation: str = "relu",
        gcn_aggregation: str = "mean",
        transformer_layers: int = 1,
        nhead: int = 4,
        ff_hidden: int = 256,
        transformer_dropout: float = 0.1,
        causal_mask: bool = False,
        use_time_features: bool = True,
        beta_init: float = 0.1,
    ):
        super().__init__()
        self.input_len = input_len
        self.horizon = horizon
        self.d_model = d_model
        self.use_time_features = use_time_features

        self.input_projection = nn.Linear(1, d_model)
        self.temporal_embedding = TemporalEmbedding(d_model)

        self.lstm_branch = VolatilityAwareLSTM(
            input_size=d_model,
            hidden_size=lstm_hidden,
            num_layers=lstm_layers,
            dropout=lstm_dropout,
            fluctuation_window=fluctuation_window,
        )
        self.gcn_branch = GCNModule(
            d_model=d_model,
            hidden_size=gcn_hidden,
            num_layers=gcn_layers,
            activation=gcn_activation,
            aggregation=gcn_aggregation,
        )
        self.transformer_branch = TransformerModule(
            d_model=d_model,
            num_heads=nhead,
            num_layers=transformer_layers,
            d_ff=ff_hidden,
            dropout=transformer_dropout,
            causal_mask=causal_mask,
        )
        self.fusion_module = FusionModule(d_model=d_model, lstm_hidden=lstm_hidden, gcn_hidden=gcn_hidden)
        self.residual_head = TrendPreservingResidualOutput(
            input_dim=d_model,
            forecast_steps=horizon,
            beta_init=beta_init,
        )

    def prepare_inputs(
        self,
        x: torch.Tensor,
        adj: torch.Tensor,
        low_freq: Optional[torch.Tensor] = None,
        time_features: Optional[torch.Tensor] = None,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        del low_freq
        _, _, num_nodes = x.shape
        x_projected = self.input_projection(x.unsqueeze(-1))

        if self.use_time_features and time_features is not None:
            time_embedding = self.temporal_embedding(time_features)
            time_embedding = time_embedding.unsqueeze(2).expand(-1, -1, num_nodes, -1)
            x_projected = x_projected + time_embedding

        return x_projected, adj

    def short_term_branches(
        self,
        x_projected: torch.Tensor,
        adj: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor]:
        batch_size, seq_len, num_nodes, d_model = x_projected.shape

        lstm_input = x_projected.permute(0, 2, 1, 3).contiguous().reshape(batch_size * num_nodes, seq_len, d_model)
        _, lstm_last = self.lstm_branch(lstm_input)
        lstm_output = lstm_last.view(batch_size, num_nodes, -1)

        gcn_output = self.gcn_branch(x_projected, adj)
        return lstm_output, gcn_output

    def long_term_branch(self, x_projected: torch.Tensor) -> torch.Tensor:
        batch_size, seq_len, num_nodes, d_model = x_projected.shape
        transformer_input = x_projected.permute(0, 2, 1, 3).contiguous().reshape(
            batch_size * num_nodes, seq_len, d_model
        )
        transformer_output, _ = self.transformer_branch(transformer_input)
        transformer_last = transformer_output[:, -1, :]
        return transformer_last.view(batch_size, num_nodes, d_model)

    def forward(
        self,
        x: torch.Tensor,
        adj: torch.Tensor,
        low_freq: Optional[torch.Tensor] = None,
        time_features: Optional[torch.Tensor] = None,
    ) -> Dict[str, torch.Tensor]:
        h0, adj = self.prepare_inputs(x, adj, low_freq, time_features)
        lstm_output, gcn_output = self.short_term_branches(h0, adj)
        transformer_output = self.long_term_branch(h0)
        short_features, fused_features = self.fusion_module(lstm_output, gcn_output, transformer_output)
        prediction, reference, dynamic_prediction = self.residual_head(fused_features, x, low_freq)

        return {
            "prediction": prediction,
            "reference": reference,
            "dynamic_prediction": dynamic_prediction,
            "beta": self.residual_head.beta,
            "h0": h0,
            "lstm_output": lstm_output,
            "gcn_output": gcn_output,
            "short_features": short_features,
            "transformer_output": transformer_output,
            "fused_features": fused_features,
        }

    def predict(
        self,
        x: torch.Tensor,
        adj: torch.Tensor,
        low_freq: Optional[torch.Tensor] = None,
        time_features: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        with torch.no_grad():
            return self.forward(x, adj, low_freq, time_features)["prediction"]

    def get_model_info(self) -> Dict[str, Any]:
        total_params = sum(p.numel() for p in self.parameters())
        trainable_params = sum(p.numel() for p in self.parameters() if p.requires_grad)
        return {
            "model_name": "MVP-STG",
            "total_parameters": total_params,
            "trainable_parameters": trainable_params,
            "input_length": self.input_len,
            "forecast_horizon": self.horizon,
            "model_dimension": self.d_model,
            "use_time_features": self.use_time_features,
        }


def create_mvp_stgpp_model(config: Dict[str, Any]) -> MVPSTGPlusPlus:
    model_cfg = config.get("model", {})
    data_cfg = config.get("data", {})
    lstm_cfg = model_cfg.get("lstm", config.get("lstm", {}))
    gcn_cfg = model_cfg.get("gcn", config.get("gcn", {}))
    transformer_cfg = model_cfg.get("transformer", config.get("transformer", {}))

    d_model = model_cfg.get("d_model", config.get("d_model", 128))
    lstm_hidden = lstm_cfg.get("hidden", d_model)
    gcn_hidden = gcn_cfg.get("hidden", lstm_hidden)

    return MVPSTGPlusPlus(
        input_len=data_cfg.get("in_len", config.get("input_length", 12)),
        horizon=data_cfg.get("horizon", config.get("output_length", 12)),
        d_model=d_model,
        lstm_hidden=lstm_hidden,
        lstm_layers=lstm_cfg.get("layers", 1),
        lstm_dropout=lstm_cfg.get("dropout", 0.0),
        fluctuation_window=lstm_cfg.get("fluctuation_window", config.get("fluctuation_window", 3)),
        gcn_hidden=gcn_hidden,
        gcn_layers=gcn_cfg.get("layers", 2),
        gcn_activation=gcn_cfg.get("act", "relu"),
        gcn_aggregation=gcn_cfg.get("aggregation", config.get("gcn_aggregation", "mean")),
        transformer_layers=transformer_cfg.get("layers", 1),
        nhead=transformer_cfg.get("heads", 4),
        ff_hidden=transformer_cfg.get("ff_hidden", 256),
        transformer_dropout=transformer_cfg.get("dropout", 0.1),
        causal_mask=transformer_cfg.get("causal_mask", False),
        use_time_features=config.get("use_time_features", True),
        beta_init=config.get("beta_init", 0.1),
    )


MVPSTGModel = MVPSTGPlusPlus


__all__ = [
    "PositionalEncoding",
    "TemporalEmbedding",
    "TransformerModule",
    "FluctuationAwareGate",
    "ImprovedLSTMCell",
    "VolatilityAwareLSTM",
    "GraphConvolution",
    "GCNModule",
    "SpatialTemporalFusion",
    "ShortLongFusion",
    "PredictionHead",
    "TrendPreservingResidualOutput",
    "MVPSTGPlusPlus",
    "MVPSTGModel",
    "create_mvp_stgpp_model",
]
