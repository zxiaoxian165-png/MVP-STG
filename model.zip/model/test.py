import os, sys, argparse, json
import numpy as np
import torch

from config import *
from data_loader import DataManager
from model import MVP_STG
from metrics import evaluate


def test(args):
    device = DEVICE

    data_path   = os.path.join(DATA_DIR, f'{args.dataset}.csv')
    coords_path = os.path.join(DATA_DIR, 'coords.csv')
    if not os.path.exists(data_path):
        raise FileNotFoundError(f'Dataset not found: {data_path}')

    dm = DataManager(data_path, coords_path,
                     input_len=INPUT_LEN, output_len=OUTPUT_LEN,
                     rms_window=RMS_WINDOW)
    dm.load_data()
    _, _, test_loader = dm.get_dataloaders(batch_size=BATCH_SIZE)

    print(f'[{args.dataset}] nodes={dm.num_nodes}, test samples={len(dm.test_set)}')

    ckpt_path = args.ckpt if args.ckpt else os.path.join(
        OUTPUT_DIR, f'mvp_stg_{args.dataset}.pt')
    if not os.path.exists(ckpt_path):
        raise FileNotFoundError(
            f'Checkpoint not found: {ckpt_path}\n'
            f'Run  python train.py --dataset {args.dataset}  first.')

    ckpt = torch.load(ckpt_path, map_location=device)
    print(f'[Checkpoint] loaded from {ckpt_path}')

    model = MVP_STG(
        num_nodes=dm.num_nodes, input_dim=1,
        output_len=OUTPUT_LEN, hidden_dim=HIDDEN_DIM,
        input_len=INPUT_LEN
    ).to(device)
    model.load_state_dict(ckpt['model_state_dict'])
    model.eval()

    adj = dm.get_normalised_adjacency().to(device)
    n_params = sum(p.numel() for p in model.parameters()) / 1e6
    print(f'[Model] D_m={HIDDEN_DIM}, params={n_params:.3f}M')

    preds_list, labels_list = [], []
    with torch.no_grad():
        for x, y, hour_idx, delta in test_loader:
            x, y = x.to(device), y.to(device)
            hour_idx = hour_idx.to(device)
            delta    = delta.to(device)
            preds_list.append(model(x, adj, hour_idx, delta).cpu().numpy())
            labels_list.append(y.cpu().numpy())

    preds  = np.concatenate(preds_list, axis=0)
    labels = np.concatenate(labels_list, axis=0)

    preds_raw  = dm.inverse_transform(preds)
    labels_raw = dm.inverse_transform(labels)

    metrics = evaluate(preds_raw, labels_raw)
    print(f'\n=== Test Results ({args.dataset}) ===')
    for k, v in metrics.items():
        suffix = '%' if 'MAPE' in k or 'SMAPE' in k else ''
        print(f'  {k:>6s}: {v:.4f}{suffix}')

    return metrics


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Test MVP-STG')
    parser.add_argument('--dataset', type=str, required=True,
                        choices=['call_in', 'call_out', 'sms_in', 'sms_out'])
    parser.add_argument('--ckpt', type=str, default=None)
    parser.add_argument('--batch_size', type=int, default=BATCH_SIZE)
    args = parser.parse_args()
    BATCH_SIZE = args.batch_size
    test(args)
