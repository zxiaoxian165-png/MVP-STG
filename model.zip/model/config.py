import os
import torch

ROOT_DIR   = os.path.dirname(os.path.abspath(__file__))
DATA_DIR   = os.path.join(ROOT_DIR, 'data')
OUTPUT_DIR = os.path.join(ROOT_DIR, 'output')

INPUT_LEN   = 12
OUTPUT_LEN  = 12
TRAIN_RATIO = 0.7
VAL_RATIO   = 0.1
RMS_WINDOW  = 6

HIDDEN_DIM  = 128
GCN_LAYERS  = 2
TRANS_LAYERS = 1
TRANS_HEADS  = 4
DROPOUT      = 0.1

BATCH_SIZE    = 16
EPOCHS        = 40
LEARNING_RATE = 0.0005
PATIENCE      = 10
HUBER_DELTA = 0.1
DEVICE        = 'cuda' if torch.cuda.is_available() else 'cpu'
SEED          = 42
