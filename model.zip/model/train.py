import os, sys, argparse, time, json
import numpy as np
import torch
import torch.nn as nn

from config import *
from data_loader import DataManager
from model import MVP_STG
from metrics import evaluate


def set_seed(seed=42):
    import random
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def train(args):
    set_seed(SEED)
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    data_path   = os.path.join(DATA_DIR, f'{args.dataset}.csv')
    coords_path = os.path.join(DATA_DIR, 'coords.csv')
    if not os.path.exists(data_path):
        raise FileNotFoundError(f'Dataset not found: {data_path}')

    dm = DataManager(data_path, coords_path,
                     input_len=INPUT_LEN, output_len=OUTPUT_LEN,
                     rms_window=RMS_WINDOW)
    dm.load_data()
    train_loader, val_loader, test_loader = dm.get_dataloaders(batch_size=BATCH_SIZE)
    adj = dm.get_normalised_adjacency().to(DEVICE)

    print(f'[{args.dataset}] nodes={dm.num_nodes}, '
          f'train={len(dm.train_set)}, val={len(dm.val_set)}, test={len(dm.test_set)}')

    model = MVP_STG(
        num_nodes=dm.num_nodes, input_dim=1, output_len=OUTPUT_LEN,
        hidden_dim=HIDDEN_DIM, input_len=INPUT_LEN
    ).to(DEVICE)

    n_params = sum(p.numel() for p in model.parameters()) / 1e6
    print(f'[Model] D_m={HIDDEN_DIM}, params={n_params:.3f}M')

    optimizer = torch.optim.AdamW(model.parameters(), lr=LEARNING_RATE,
                                   weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, patience=5, factor=0.5)
    criterion = nn.HuberLoss(delta=HUBER_DELTA)

    best_val_loss = float('inf')
    best_state    = None
    patience_counter = 0

    for epoch in range(EPOCHS):
        t0 = time.perf_counter()

        model.train()
        train_loss = 0.0
        for x, y, hour_idx, delta in train_loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            hour_idx = hour_idx.to(DEVICE)
            delta    = delta.to(DEVICE)

            optimizer.zero_grad()
            preds = model(x, adj, hour_idx, delta)
            loss  = criterion(preds, y)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=5.0)
            optimizer.step()
            train_loss += loss.item()
        train_loss /= len(train_loader)

        model.eval()
        val_loss = 0.0
        with torch.no_grad():
            for x, y, hour_idx, delta in val_loader:
                x, y = x.to(DEVICE), y.to(DEVICE)
                hour_idx = hour_idx.to(DEVICE)
                delta    = delta.to(DEVICE)
                val_loss += criterion(model(x, adj, hour_idx, delta), y).item()
        val_loss /= len(val_loader)

        dt     = time.perf_counter() - t0
        marker = ''
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_state = {k: v.cpu().clone() for k, v in model.state_dict().items()}
            patience_counter = 0
            marker = ' *'
        else:
            patience_counter += 1

        print(f'Epoch {epoch+1:3d}/{EPOCHS} | '
              f'train={train_loss:.6f} | val={val_loss:.6f} | {dt:.1f}s{marker}')

        if patience_counter >= PATIENCE:
            print(f'Early stopping at epoch {epoch+1}')
            break
        scheduler.step(val_loss)

    model.load_state_dict(best_state)
    ckpt_path = os.path.join(OUTPUT_DIR, f'mvp_stg_{args.dataset}.pt')
    torch.save({
        'model_state_dict': model.state_dict(),
        'num_nodes':   dm.num_nodes,
        'input_len':   INPUT_LEN,
        'output_len':  OUTPUT_LEN,
        'hidden_dim':  HIDDEN_DIM,
        'mean_val':    dm.mean_val,
        'std_val':     dm.std_val,
        'adj':         adj.cpu(),
    }, ckpt_path)
    print(f'[Checkpoint] saved to {ckpt_path}')

    model.eval()
    preds_list, labels_list = [], []
    with torch.no_grad():
        for x, y, hour_idx, delta in test_loader:
            x, y = x.to(DEVICE), y.to(DEVICE)
            hour_idx = hour_idx.to(DEVICE)
            delta    = delta.to(DEVICE)
            preds_list.append(model(x, adj, hour_idx, delta).cpu().numpy())
            labels_list.append(y.cpu().numpy())

    preds  = np.concatenate(preds_list, axis=0)
    labels = np.concatenate(labels_list, axis=0)

    preds_raw  = dm.inverse_transform(preds)
    labels_raw = dm.inverse_transform(labels)

    metrics = evaluate(preds_raw, labels_raw)
    print(f'\n=== Test Results ({args.dataset}) ===')
    for k, v in metrics.items():
        suffix = '%' if 'MAPE' in k or 'SMAPE' in k else ''
        print(f'  {k:>6s}: {v:.4f}{suffix}')

    metrics_path = os.path.join(OUTPUT_DIR, f'mvp_stg_{args.dataset}_metrics.json')
    with open(metrics_path, 'w') as f:
        json.dump({**metrics, 'dataset': args.dataset,
                   'params_M': n_params}, f, indent=2)
    print(f'[Metrics] saved to {metrics_path}')

    return metrics


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Train MVP-STG')
    parser.add_argument('--dataset', type=str, required=True,
                        choices=['call_in', 'call_out', 'sms_in', 'sms_out'])
    parser.add_argument('--epochs',    type=int,   default=EPOCHS)
    parser.add_argument('--lr',        type=float, default=LEARNING_RATE)
    parser.add_argument('--batch_size',type=int,   default=BATCH_SIZE)
    parser.add_argument('--hidden_dim',type=int,   default=HIDDEN_DIM)
    args = parser.parse_args()

    EPOCHS        = args.epochs
    LEARNING_RATE = args.lr
    BATCH_SIZE    = args.batch_size
    HIDDEN_DIM    = args.hidden_dim

    train(args)
