import numpy as np


def masked_mae(preds, labels):
    return float(np.mean(np.abs(preds - labels)))


def masked_rmse(preds, labels):
    return float(np.sqrt(np.mean(np.square(preds - labels))))


def masked_smape(preds, labels):
    denom = np.abs(preds) + np.abs(labels)
    smape = 200.0 * np.abs(preds - labels) / (denom + 1e-8)
    return float(np.mean(smape))


def masked_mape(preds, labels):
    mask = labels > 10.0
    if mask.sum() == 0:
        return 0.0
    mape = np.abs((preds[mask] - labels[mask]) / labels[mask])
    return float(np.mean(mape)) * 100.0


def evaluate(preds, labels):
    preds = np.clip(preds, 0, None)
    return {
        'MAE':   masked_mae(preds, labels),
        'RMSE':  masked_rmse(preds, labels),
        'SMAPE': masked_smape(preds, labels),
        'MAPE':  masked_mape(preds, labels),
    }
