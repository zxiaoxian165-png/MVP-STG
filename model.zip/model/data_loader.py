import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader
from scipy.spatial.distance import pdist, squareform


class TrafficDataset(Dataset):
    def __init__(self, data, hour_idx, delta, input_len, output_len):
        self.data     = torch.FloatTensor(data)
        self.hour_idx = torch.LongTensor(hour_idx)
        self.delta    = torch.FloatTensor(delta)
        self.input_len  = input_len
        self.output_len = output_len

    def __len__(self):
        return len(self.data) - self.input_len - self.output_len + 1

    def __getitem__(self, idx):
        x = self.data[idx: idx + self.input_len]
        y = self.data[idx + self.input_len:
                      idx + self.input_len + self.output_len]
        h = self.hour_idx[idx: idx + self.input_len]
        d = self.delta[idx: idx + self.input_len]
        return x, y, h, d


class DataManager:
    def __init__(self, data_path, coords_path=None,
                 input_len=12, output_len=12,
                 train_ratio=0.7, val_ratio=0.1,
                 rms_window=6, start_hour=0):
        self.data_path   = data_path
        self.coords_path = coords_path
        self.input_len   = input_len
        self.output_len  = output_len
        self.train_ratio = train_ratio
        self.val_ratio   = val_ratio
        self.rms_window  = rms_window
        self.start_hour  = start_hour

        self.mean_val  = 0.0
        self.std_val   = 1.0
        self.num_nodes = 0

        self.train_set = None
        self.val_set   = None
        self.test_set  = None

    def load_data(self):
        df = pd.read_csv(self.data_path, header=None)
        df = df.apply(pd.to_numeric, errors='coerce')
        df = df.dropna(axis=1, how='all')
        df = df.ffill().bfill()

        raw_data = df.values.astype(np.float32)
        self.num_nodes = raw_data.shape[1]
        T_total = raw_data.shape[0]

        data_log = np.log1p(raw_data)
        self.mean_val = float(np.mean(data_log))
        self.std_val  = float(np.std(data_log)) + 1e-8
        data_norm = (data_log - self.mean_val) / self.std_val

        hour_idx = np.arange(T_total) % 24
        hour_idx = hour_idx.astype(np.int64)

        delta = self._compute_rms_deviation(raw_data, self.rms_window)

        n = len(data_norm)
        n_train = int(n * self.train_ratio)
        n_val   = int(n * self.val_ratio)

        self.train_set = TrafficDataset(
            data_norm[:n_train], hour_idx[:n_train], delta[:n_train],
            self.input_len, self.output_len)
        self.val_set = TrafficDataset(
            data_norm[n_train:n_train + n_val],
            hour_idx[n_train:n_train + n_val],
            delta[n_train:n_train + n_val],
            self.input_len, self.output_len)
        self.test_set = TrafficDataset(
            data_norm[n_train + n_val:],
            hour_idx[n_train + n_val:],
            delta[n_train + n_val:],
            self.input_len, self.output_len)

        return self.train_set, self.val_set, self.test_set

    def _compute_rms_deviation(self, raw, window):
        padded = np.pad(raw, ((window - 1, 0), (0, 0)), mode='edge')
        windows = np.lib.stride_tricks.sliding_window_view(padded, window, axis=0)
        mu  = np.mean(windows, axis=-1, keepdims=True)
        rms = np.sqrt(np.mean((windows - mu) ** 2, axis=-1))
        rms = rms / (np.max(rms) + 1e-8)
        return rms.astype(np.float32)

    def get_dataloaders(self, batch_size=16, num_workers=0):
        train_loader = DataLoader(self.train_set, batch_size=batch_size,
                                  shuffle=True, num_workers=num_workers,
                                  pin_memory=True)
        val_loader   = DataLoader(self.val_set, batch_size=batch_size,
                                  shuffle=False, num_workers=num_workers,
                                  pin_memory=True)
        test_loader  = DataLoader(self.test_set, batch_size=batch_size,
                                  shuffle=False, num_workers=num_workers,
                                  pin_memory=True)
        return train_loader, val_loader, test_loader

    def inverse_transform(self, data):
        data_log = data * self.std_val + self.mean_val
        return np.expm1(data_log)

    def get_normalised_adjacency(self):
        if self.coords_path is not None:
            try:
                coords = pd.read_csv(self.coords_path, header=None)
                if coords.shape[0] >= self.num_nodes:
                    coords_np = coords.iloc[:self.num_nodes, :2].values
                    dists = squareform(pdist(coords_np))
                    sigma = 0.1
                    adj = np.exp(-dists ** 2 / (sigma ** 2))
                    adj[adj < 0.1] = 0.0
                    adj_t = torch.FloatTensor(adj)
                    return self._normalise_adj(adj_t)
            except Exception:
                pass

        train_data = self.train_set.data.numpy()
        adj = np.corrcoef(train_data.T)
        adj = np.nan_to_num(adj)
        adj_t = torch.FloatTensor(adj)
        return self._normalise_adj(adj_t)

    def _normalise_adj(self, adj):
        adj = adj + torch.eye(adj.size(0))
        deg = adj.sum(dim=1)
        deg_inv_sqrt = torch.pow(deg.clamp(min=1), -0.5)
        return deg_inv_sqrt.unsqueeze(1) * adj * deg_inv_sqrt.unsqueeze(0)
